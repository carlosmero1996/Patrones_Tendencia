/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorymethod;

/**
 *
 * @author Abel Gomez
 */
public class FactoryMethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        FabricaTransporte fabrica = new FabricaTransporte();
        Transporte camion = fabrica.crearTransporte("camion");
        camion.entregar();
        Transporte barco = fabrica.crearTransporte("barco");
        barco.entregar();
        Transporte barco2 = fabrica.crearTransporte("barco");
        barco.entregar();
    }

}
