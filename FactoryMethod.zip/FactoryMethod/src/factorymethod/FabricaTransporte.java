/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorymethod;

/**
 *
 * @author Abel Gomez
 */
public class FabricaTransporte {

    public Transporte crearTransporte(String tipo) {
        if (tipo.equalsIgnoreCase("camion")) {
            return new Camion();
        } else if (tipo.equalsIgnoreCase("barco")) {
            return new Barco();
        }
        return null;
    }
}
