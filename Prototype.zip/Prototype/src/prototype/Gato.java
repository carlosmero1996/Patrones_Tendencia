/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author Abel Gomez
 */
public class Gato extends Animal {

    private String pelaje;

    public Gato(String especie, String pelaje) {
        super(especie);
        this.pelaje = pelaje;
    }

    public String getPelaje() {
        return pelaje;
    }

    public void setPelaje(String pelaje) {
        this.pelaje = pelaje;
    }

    @Override
    public Animal clonar() {
        return new Gato(getEspecie(), pelaje);
    }

}
