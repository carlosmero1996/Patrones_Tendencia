/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author Abel Gomez
 */
public class Prototype {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Perro perroPrototipo = new Perro("canino", "Doberman");
        Gato gatoPrototipo = new Gato("felino", "siames");

        Animal perroClonado = perroPrototipo.clonar();
        Animal gatoClonado = gatoPrototipo.clonar();
        System.out.println("Original  =>"+perroPrototipo.getEspecie()+" "+perroPrototipo.getRaza());

        System.out.println("Copia =>"+perroClonado.getEspecie() + " " + ((Perro) perroClonado).getRaza());
        System.out.println(gatoClonado.getEspecie() + " " + ((Gato) gatoClonado).getPelaje());
    }

}
